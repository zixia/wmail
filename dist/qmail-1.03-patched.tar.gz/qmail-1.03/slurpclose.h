#ifndef SLURPCLOSE_H
#define SLURPCLOSE_H

extern int slurpclose();

#endif
