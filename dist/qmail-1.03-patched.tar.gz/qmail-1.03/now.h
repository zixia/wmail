#ifndef NOW_H
#define NOW_H

#include "datetime.h"

extern datetime_sec now();

#endif
