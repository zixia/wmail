QMAIL/bin/maildir2mbox && exec Mail ${1+"$@"}
