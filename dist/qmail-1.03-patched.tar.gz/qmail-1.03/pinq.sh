QMAIL/bin/maildir2mbox && exec pine ${1+"$@"}
