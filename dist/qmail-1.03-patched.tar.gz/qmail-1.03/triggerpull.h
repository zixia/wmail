#ifndef TRIGGERPULL_H
#define TRIGGERPULL_H

extern void triggerpull();

#endif
