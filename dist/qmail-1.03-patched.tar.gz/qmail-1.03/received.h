#ifndef RECEIVED_H
#define RECEIVED_H

extern void received();

#endif
