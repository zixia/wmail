#ifndef FIFO_H
#define FIFO_H

extern int fifo_make();

#endif
