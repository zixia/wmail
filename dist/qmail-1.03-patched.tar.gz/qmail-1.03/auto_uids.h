#ifndef AUTO_UIDS_H
#define AUTO_UIDS_H

extern int auto_uida;
extern int auto_uidd;
extern int auto_uidl;
extern int auto_uido;
extern int auto_uidp;
extern int auto_uidq;
extern int auto_uidr;
extern int auto_uids;

extern int auto_gidn;
extern int auto_gidq;

#endif
