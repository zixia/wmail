#ifndef REMOTEINFO_H
#define REMOTEINFO_H

extern char *remoteinfo_get();

#endif
