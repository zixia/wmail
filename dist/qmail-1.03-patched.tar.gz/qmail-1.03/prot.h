#ifndef PROT_H
#define PROT_H

extern int prot_gid();
extern int prot_uid();

#endif
