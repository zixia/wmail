#ifndef QUOTE_H
#define QUOTE_H

extern int quote_need();
extern int quote();
extern int quote2();

#endif
