QMAIL/bin/maildir2mbox && exec elm ${1+"$@"}
