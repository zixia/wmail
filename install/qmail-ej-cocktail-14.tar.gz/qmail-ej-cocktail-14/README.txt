Im Eunjea <eunjea@kldp.org> 2003/09/19
http://people.kldp.org/~eunjea/qmail_cocktail.php
http://people.kldp.org/~eunjea/qmail/patch/
----------------------------------------------------------------------

This patch combines following patches.

	1. qmail-1.03-tls.patch (20021228)
	2. qmail-smtpd-auth-0.31
	3. big-concurrency.patch
	4. qmail-103.patch (oversize DNS packets)
	5. qmail-date-localtime.patch
	6. qmail-smtpd-newline.patch
	7. badrcptto.patch (v1.02)
	8. nullenvsender-recipcount (v1.5)
	9. qmail-queue
	10. doublebounce-trim
	11. qmail-smtpd-relay-reject
	12. log patch:
			attempt relay log
			qmail-smtpd-log-badmailfrom.patch

qmail.org recommended patches (http://qmail.org/top.html#patches)

	13. qmail-local bug patch
	14. qmail-0.0.0.0.patch
	15. sendmail-flagf.patch
	16. fix for glibc(2.3.1)

Sources:
http://qmail.org/big-concurrency.patch
http://www.ckdhr.com/ckd/qmail-103.patch
ftp://ftp.nlc.net.au/pub/unix/mail/qmail/qmail-date-localtime.patch
http://www.qcc.sk.ca/~charlesc/software/misc/nullenvsender-recipcount.patch
http://inoa.net/qmail/qmail-1.03-tls.patch (STARTTLS)
http://members.elysium.pl/brush/qmail-smtpd-auth/        (SMTP AUTH)
http://patch.be/qmail/badrcptto.html
http://qmail.org/moni.csi.hu/pub/glibc-2.3.1/
http://www.ornl.gov/its/archives/mailing-lists/qmail/2000/10/msg00696.html
http://www.suspectclass.com/~sgifford/qmail/qmail-0.0.0.0.patch
http://david.acz.org/software/sendmail-flagf.patch
http://www.qmail.org/qmailqueue-patch
http://qmail.org/doublebounce-trim.patch
http://qmail.org/qmail-smtpd-relay-reject

Usage:
Apply this patch to vanilla qmail source, compile, install & enjoy. ;)
$ patch -p1 < cocktail.patch
Check each documents from original patch for usage.
