#ifndef PARSETYPE_H
#define PARSETYPE_H

extern int parsetype(char *,char *);

#endif
