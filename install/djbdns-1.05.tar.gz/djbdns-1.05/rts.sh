env - PATH="`pwd`:$PATH" sh rts.tests 2>&1 | cat -v
