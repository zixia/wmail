#ifndef AUTO_UCSPI_TCP_H
#define AUTO_UCSPI_TCP_H

extern char auto_ucspi_tcp[];

#endif
