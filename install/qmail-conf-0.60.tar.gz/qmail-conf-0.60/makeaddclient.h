#ifndef MAKEADDCLIENT_H
#define MAKEADDCLIENT_H

extern void makeaddclient (void);

#endif
