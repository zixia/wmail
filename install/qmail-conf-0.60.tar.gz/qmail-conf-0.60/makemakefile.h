#ifndef MAKEMAKEFILE_H
#define MAKEMAKEFILE_H

extern void makemakefile (void);

#endif
