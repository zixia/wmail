#ifndef MAKEADDRELAYCLIENT_H
#define MAKEADDRELAYCLIENT_H

extern void makeaddrelayclient (void);

#endif
